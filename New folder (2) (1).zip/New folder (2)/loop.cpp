#include <iostream>

int main() {
    
    int numbers[5] = {15, 25, 30, 48, 59};
    for (int i = 0; i < 5; i++) {
        std::cout << "Number at index " << i << ": " << numbers[i] << std::endl;
    }

    return 0;
}

