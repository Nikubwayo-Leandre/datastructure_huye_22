#include<iostream>
using namespace std;

int func_add(int x, int y) {
    return x + y;
}

int func_sub(int x, int y) {
    return x - y;
}

int func_mul(int x, int y) {
    return x * y;
}

int func_div(int x, int y) {
    if (y == 0) {
        cout << "Error: Division by zero is not allowed!" << endl;
        return 0; 
    }
    return x / y;
}

int main() {
    int a, b, result;
    char operation;

    cout << "Enter first number: ";
    cin >> a;
    cout << "Enter second number: ";
    cin >> b;

    cout << "Choose operation (+, -, *, /): ";
    cin >> operation;

    switch (operation) {
        case '+':
            result = func_add(a, b);
            cout << "The sum is: " << result << endl;
            break;
        case '-':
            result = func_sub(a, b);
            cout << "The difference is: " << result << endl;
            break;
        case '*':
            result = func_mul(a, b);
            cout << "The product is: " << result << endl;
            break;
        case '/':
            result = func_div(a, b);
            if (b != 0)  
                cout << "The division is: " << result << endl;
            break;
        default:
            cout << "Invalid operation!" << endl;
    }

    return 0;
}
